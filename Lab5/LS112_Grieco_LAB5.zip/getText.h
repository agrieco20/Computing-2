
//
// Created by Adam Albina on 3/3/21.
//

#ifndef LAB5_GETTEXT_H
#define LAB5_GETTEXT_H
#include <vector>
#include <string>
std::vector<std::string> getText();
#endif //LAB5_GETTEXT_H
