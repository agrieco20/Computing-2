/**
 * Filename: problem_4.cpp
 * Author: Anthony Grieco
 * Description: This program prints out the amount of time that I will be studying for the mid-term exam.
 */

#include <iostream>

using namespace std;

int main() {
    cout << "I plan on studying for the midterm a few hours a night so that I can do well on it. \nThat means I will probably spend between 10 - 12 hours studying for this test." << endl;
    return 0;
}