/******
 * Header file for grade.cpp
 */

#include<vector>

#ifndef LAB4_GRADES_H
#define LAB4_GRADES_H
std::vector<double>getGrades();
#endif //LAB4_GRADES_H
